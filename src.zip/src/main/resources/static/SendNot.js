$(document).ready(function() {
    // Always show the modal on page load
    $('#messageModal').modal('show');
});
