const express = require('express');
const multer = require('multer');
const path = require('path');

const app = express();

// 设置multer的存储方式为磁盘存储
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        // 设置上传后文件的存储位置
        cb(null, '/home/upload/')
    },
    filename: function (req, file, cb) {
        // 设置上传后文件的名称，这里使用原始文件名+时间戳
        cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname))
    }
})

const upload = multer({ storage: storage })

app.post('/upload-avatar', upload.single('avatar'), (req, res) => {
    // 文件上传成功后，返回文件的访问路径
    res.status(200).send({ message: 'Avatar uploaded successfully!', path: '/uploads/' + req.file.filename });
});

app.listen(3000, () => {
    console.log('Server is running on port 3000');
});