package group27.xukai.cpt202b;

import group27.xukai.cpt202b.service.UserManageServiceImpl;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.FilterType;


@SpringBootApplication
@ComponentScan(excludeFilters = {
        @ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, value = UserManageServiceImpl.class)
})
public class Cpt202BApplication {
    public static void main(String[] args) {
        SpringApplication.run(Cpt202BApplication.class, args);
    }
}
