package group27.xukai.cpt202b.controller;

import group27.xukai.cpt202b.entity.FitnessPlan;
import group27.xukai.cpt202b.entity.Member;
import group27.xukai.cpt202b.service.FitnessPlanService;
import group27.xukai.cpt202b.service.MemberService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDateTime;
import java.util.List;

@Controller
@RequestMapping("/member/fitnessplan")
public class FitnessPlanController {
    @Autowired
    private FitnessPlanService fitnessPlanService;

    @Autowired
    private MemberService memberService;

    @GetMapping("page")
    public String getFitnessPlan(Model model, HttpSession session) {
        int userId = (int) session.getAttribute("userId");

        // 检查数据库中是否已经存在具有相同 userId 的记录
        Member existingMember = memberService.getMemberByUserId(userId);

        // 如果已经存在具有相同 userId 的记录，则不需要创建新的 Member 对象
        if (existingMember == null) {
            // 创建新的 Member 对象，并设置 userId 属性
            Member newMember = new Member();
            newMember.setUserId(userId);

            // 保存新的 Member 对象到数据库中
            memberService.saveMember(newMember);
        }

        List<FitnessPlan> fitnessPlans = fitnessPlanService.getFitnessPlanData();
        model.addAttribute("fitnessPlans", fitnessPlans);
        return "FitnessPlan";
    }


    @GetMapping("/View") // 查看所有会员的健身计划购买情况
    public String getMember(@RequestParam(defaultValue = "1") int page,
                            @RequestParam(defaultValue = "10") int size,
                            Model model, HttpSession session) {
        int userId = (int) session.getAttribute("userId");
        LocalDateTime startTime = memberService.getStartTime(userId);

        // 判断 purchasePlanId 是否为 null，并将结果传递到前端页面
        boolean hasPurchasePlan = (startTime != null);
        model.addAttribute("hasPurchasePlan", hasPurchasePlan);

        // 获取会员数据
        Page<Member> memberFitnessPlanPage = memberService.findMembersWithFitnessPlan(PageRequest.of(page - 1, size));

        // 遍历会员数据，更新健身计划状态并更新数据库
        for (Member member : memberFitnessPlanPage) {
            if (member.getEndTime() != null) {
                if (member.getEndTime().isBefore(LocalDateTime.now())) {
                    member.setPlanState("Expired"); // 更新状态为已过期
                } else {
                    member.setPlanState("Valid"); // 更新状态为有效
                }
                // 更新数据库中的状态字段
                memberService.updateMemberState(member.getId(), member.getPlanState());
            } else {
                member.setPlanState(null);
            }
        }

        // 将更新后的会员数据传递到前端
        model.addAttribute("members", memberFitnessPlanPage.getContent());
        model.addAttribute("currentPage", page); // 不再进行加1操作
        model.addAttribute("totalPages", memberFitnessPlanPage.getTotalPages());

        // 返回模板名称，Thymeleaf 将根据模板名称渲染页面
        return "ViewAllMemberFitnessPlan";
    }


}


