package group27.xukai.cpt202b.controller;


import group27.xukai.cpt202b.entity.Manager;
import group27.xukai.cpt202b.mapper.managerMapper;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@Controller
public class managerController {
    @Resource
    private managerMapper managerMapper;
    @PostMapping("/managerlogin")
    public Manager managerlogin(@RequestBody Manager manager) {
        Manager dbManager = managerMapper.getManagerByNameAndPassword(manager.getManagerID(), manager.getPassword());
        return dbManager;
    }

    @GetMapping("/manager")
    public String managerDashboard() {
        return "managerhomepage";
    }
}
