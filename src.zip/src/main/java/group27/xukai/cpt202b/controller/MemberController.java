package group27.xukai.cpt202b.controller;

import group27.xukai.cpt202b.entity.FitnessPlan;
import group27.xukai.cpt202b.entity.Member;
import group27.xukai.cpt202b.entity.Planrecord;
import group27.xukai.cpt202b.service.FitnessPlanService;
import group27.xukai.cpt202b.service.MemberService;
import group27.xukai.cpt202b.service.PlanrecordService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * Purchase a fitness plan before membership appointment
 */
@Controller
@RequestMapping("/member/fitnessplan")
public class MemberController {

    @Autowired
    private MemberService memberService;

    @Autowired
    private FitnessPlanService fitnessPlanService;

    @Autowired
    private PlanrecordService planrecordService;

    @GetMapping("/ViewMy")
    public String getMember(Model model, HttpSession session) {
        int userId = (int) session.getAttribute("userId");

        LocalDateTime StartTime = memberService.getStartTime(userId);

        // 判断 purchasePlanId 是否为 null，并将结果传递到前端页面
        boolean hasPurchasePlan = (StartTime != null);
        model.addAttribute("hasPurchasePlan", hasPurchasePlan);

        // 获取会员数据
        List<Member> members = memberService.getMemberData();

        // 遍历会员数据，更新健身计划状态并更新数据库
            for (Member member : members) {
                if (member.getEndTime() != null) {
                    if (member.getEndTime().isBefore(LocalDateTime.now())) {
                        member.setPlanState("Expired"); // 更新状态为已过期
                    } else {
                        member.setPlanState("Valid"); // 更新状态为有效
                    }
                    // 更新数据库中的状态字段
                    memberService.updateMemberState(member.getId(), member.getPlanState());
                }else {
                    member.setPlanState(null);
                }
            }


        // 将更新后的会员数据传递到前端
        model.addAttribute("members", members);

        // 返回模板名称，Thymeleaf 将根据模板名称渲染页面
        return "ViewMyFitnessPlan";
    }


    @GetMapping("/getBalance")
    public ResponseEntity<Integer> getBalance(HttpSession session) {
        int userId = (int) session.getAttribute("userId");
        // 根据用户ID从数据库中获取用户的余额

        Integer balance = memberService.getMemberBalance(userId);
        if (balance != 0){
        return ResponseEntity.ok(balance);
        }
        else {
            return ResponseEntity.ok(0);
        }
    }

    @PostMapping("/buy")
    public ResponseEntity<String> buy(@RequestBody Map<String, Integer> requestBody,HttpSession session) {
        Integer planId = requestBody.get("planId");
        int Id = (int) session.getAttribute("userId");
        if (Id == 0 || planId == null) {
            return ResponseEntity.badRequest().body("Invalid memberId or planId");
        }

        FitnessPlan fitnessPlan = fitnessPlanService.getFitnessPlanById(planId);
        if (fitnessPlan == null) {
            return ResponseEntity.badRequest().body("Invalid planId");
        }


        double planPrice = fitnessPlan.getPlanPrice();

        // 从数据库中获取会员当前余额
        double currentBalance = memberService.getMemberBalance(Id);

        // 检查余额是否足够支付计划价格
        if (currentBalance < planPrice) {
            return ResponseEntity.badRequest().body("Insufficient balance, purchase failed!");
        }
        return ResponseEntity.ok("Member's balance is enough!");
    }

    @GetMapping("/updateUserId")
    public ResponseEntity<Integer> updateUserId(HttpSession session){
        int userId = (int) session.getAttribute("userId");
        memberService.updateUserId(userId);
        return ResponseEntity.ok(userId);
    }

    @PostMapping("/updateBalanceLevelDate")
    public ResponseEntity<String> updateBalanceLevelDate(@RequestBody Map<String, Integer> requestBody,HttpSession session) {
        Integer planId = requestBody.get("planId");
        int userId = (int) session.getAttribute("userId");

        if (userId == 0 || planId == null) {
            return ResponseEntity.badRequest().body("Invalid memberId or planId");
        }

        FitnessPlan fitnessPlan = fitnessPlanService.getFitnessPlanById(planId);
        if (fitnessPlan == null) {
            return ResponseEntity.badRequest().body("Invalid planId");
        }

        String planLevel = fitnessPlan.getPlanLevel();
        String planDate = fitnessPlan.getPlanDate();
        int planPrice = fitnessPlan.getPlanPrice();

        // 从数据库中获取会员当前余额
        int currentBalance = memberService.getMemberBalance(userId);

        // 更新会员的计划级别和计划日期
        memberService.updateMemberWithFitnessPlan(planLevel, planDate, userId);
        memberService.updateMemberPurchasePlanId(planId, userId);

        // 计算扣除计划价格后的新余额
        int newBalance = currentBalance - planPrice;

        // 更新数据库中会员的余额
        memberService.updateMemberBalance(newBalance, userId);

        // 更新会员的时间信息
        LocalDateTime startTime = LocalDateTime.now();
        LocalDateTime endTime = null; // 初始化 endTime

        if (Objects.equals(fitnessPlan.getPlanDate(), "6 months")) {
            endTime = startTime.plusMonths(6);
        }
        if (Objects.equals(fitnessPlan.getPlanDate(), "12 months")) {
            endTime = startTime.plusMonths(12);
        }

// 确保 endTime 在此处被赋值后才调用 updateTime 方法
        if (endTime != null) {
            memberService.updateTime(userId, startTime, endTime);
        }
        return ResponseEntity.ok("Member's fitness plan, balance, and time updated successfully!");
    }

    @PostMapping("/deleteAndUpdatePlan")
    public ResponseEntity<String> Update(@RequestBody Map<String, Integer> requestBody, HttpSession session) {
        Integer value = requestBody.get("purchasePlanId");
        int purchasePlanId = value != null ? value.intValue() : 0;
        int userId = (int) session.getAttribute("userId");
        if (userId == 0 || purchasePlanId == 0) {
            return ResponseEntity.badRequest().body("Invalid memberId");
        }

        FitnessPlan fitnessPlan = fitnessPlanService.getFitnessPlanById(purchasePlanId);

        if (fitnessPlan == null) {
            return ResponseEntity.badRequest().body("Invalid planId");
        }

        // Get the start time of the fitness plan
        LocalDateTime startTime = memberService.getStartTime(userId);


        // Calculate the current date
        LocalDateTime currentTime = LocalDateTime.now();

        if (startTime.plusDays(15).isBefore(currentTime)){
            return ResponseEntity.badRequest().body("You have already purchased this plan over 15 days ago. Cancelling is not allowed.");
        }

        double planPrice = fitnessPlan.getPlanPrice();
        double currentBalance = memberService.getMemberBalance(userId);
        double newBalance1 = currentBalance + planPrice * 0.8;
        int newBalance = (int) newBalance1;

        // 更新数据库中会员的余额
        memberService.updateMemberBalance(newBalance, userId);
        // 调用服务层方法删除会员信息
        memberService.clearMemberData(userId);

        return ResponseEntity.ok("Member's fitness plan, balance, and time updated successfully!");
    }

    @PostMapping("/recharge")
    public ResponseEntity<String> recharge(@RequestBody Map<String, Integer> requestBody,HttpSession session) {
        //获取充值的金额
        Integer rechargeAmount = requestBody.get("amount");
        Integer userId = (Integer) session.getAttribute("userId");

        if (rechargeAmount == null || rechargeAmount <= 0 || userId == null) {
            return ResponseEntity.badRequest().body("Invalid memberId or rechargeAmount");
        }

        // 从数据库中获取会员当前余额
        Integer currentBalance = memberService.getMemberBalance(userId);

        // 计算充值后的新余额
        Integer newBalance = currentBalance + rechargeAmount;

        // 更新数据库中会员的余额
        memberService.updateMemberBalance(newBalance, userId);


        String userName = (String) session.getAttribute("userName");
        Planrecord newRecord = new Planrecord();
        newRecord.setUsername(userName);
        // 更新会员的时间信息
        LocalDateTime startTime = LocalDateTime.now();

        // 保存新的 Planrecord 对象到数据库中
        planrecordService.saveRecord(newRecord);
        planrecordService.addRecord(startTime,rechargeAmount,userName);
        return ResponseEntity.ok("Member's recharge record updated successfully!");

//        return ResponseEntity.ok("Member's balance updated successfully!");
    }

}