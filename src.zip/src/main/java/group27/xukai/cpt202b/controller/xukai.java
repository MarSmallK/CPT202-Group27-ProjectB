package group27.xukai.cpt202b.controller;

import group27.xukai.cpt202b.entity.Appo;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class xukai {
    @GetMapping("/appo/xukai")
    public String xukaipage(){
        return "AppoDisplayMember2";
    }

    @GetMapping("/appo/mjq")
    public String mjqpage(){
        return "FinancialReport";
    }

    @GetMapping("/FinReport")
    public ModelAndView addPageAppo(HttpServletRequest request, Model model) {
        model.addAttribute("finreport", new Appo());

        return new ModelAndView("", "finreport", model);

    }
}
