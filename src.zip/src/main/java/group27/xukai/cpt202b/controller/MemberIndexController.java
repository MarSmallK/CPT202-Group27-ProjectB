package group27.xukai.cpt202b.controller;

import group27.xukai.cpt202b.entity.User;
import group27.xukai.cpt202b.service.MemberIndexService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class MemberIndexController {
    @Autowired
    private MemberIndexService memberIndexService;

    @GetMapping("/memberindex")
    public String memberIndex(Model model, HttpSession session) {
        Integer userId = (Integer) session.getAttribute("userId");
        if (userId == null) {
            return "redirect:/login"; // 如果未登录，重定向到登录页面
        }

        User user = memberIndexService.getUserById(userId);
        if (user == null) {
            return "ErrorPage"; // 处理找不到用户的情况，假设你有一个错误页面
        }


        model.addAttribute("user", user);
        return "MemberIndex"; // 返回到合适的页面
    }


    @PostMapping("/logout")
    public String logout(HttpSession session) {
        session.removeAttribute("userId");
        session.removeAttribute("username");
        return "redirect:/login";
    }
}