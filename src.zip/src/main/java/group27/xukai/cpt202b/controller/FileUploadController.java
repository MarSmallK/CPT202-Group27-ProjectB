package group27.xukai.cpt202b.controller;

import group27.xukai.cpt202b.entity.User;
import group27.xukai.cpt202b.repository.UserRepo;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.tomcat.util.http.fileupload.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.util.FileCopyUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Objects;

@RestController
public class FileUploadController {

    @Autowired
    private UserRepo userRepo;

    @Value("${fileUpload.path}")
    private String uploadPath;

    @PostMapping("/upload-avatar/{userId}")
    public ResponseEntity<?> uploadAvatar(@PathVariable Integer userId, @RequestParam("avatar") MultipartFile file) {
        if (file.isEmpty()) {
            return ResponseEntity.badRequest().body("File is empty");
        }
        try {
            String imageUrl = storeFile(userId, file); // Store the file and get the URL
            return ResponseEntity.ok("File uploaded successfully. File URL: " + imageUrl);
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Failed to upload file: " + e.getMessage());
        }
    }

    private String storeFile(Integer uid, MultipartFile file) throws IOException {
        String fileName = StringUtils.cleanPath(Objects.requireNonNull(file.getOriginalFilename()));
        // Add a unique suffix to the file name
        fileName = fileName + "-" + System.currentTimeMillis();
        File dest = new File(uploadPath + fileName); // 修改这里，去掉"userImage" + File.separator

        FileUtils.forceMkdirParent(dest);
        String absolutePath = dest.getPath();
        try (FileOutputStream fileOutputStream = new FileOutputStream(dest)) {
            FileCopyUtils.copy(file.getInputStream(), fileOutputStream);
        }
        User user = userRepo.findById(uid).orElseThrow(() -> new RuntimeException("User not found"));
        user.setImageURL(absolutePath);
        userRepo.save(user);

        return user.getImageURL();
    }

    @GetMapping("/readUserImg/{userId}")
    public void readUserImg(@PathVariable Integer userId, HttpServletResponse response){
        User user = userRepo.findById(userId).orElseThrow(() -> new RuntimeException("User not found"));
        String imageURL = user.getImageURL();
        try {
            FileInputStream imgIn = new FileInputStream(new File(imageURL));
            byte[] buffer = new byte[1024];
            ServletOutputStream outputStream = response.getOutputStream();
            while ((imgIn.read(buffer)) != -1){
                outputStream.write(buffer);
            }
            imgIn.close();
            outputStream.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}