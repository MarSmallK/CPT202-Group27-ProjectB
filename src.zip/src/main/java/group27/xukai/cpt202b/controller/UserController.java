package group27.xukai.cpt202b.controller;

import group27.xukai.cpt202b.entity.User;
import group27.xukai.cpt202b.mapper.userMapper;
import jakarta.annotation.Resource;
import jakarta.servlet.http.HttpSession;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
public class UserController {
    @Resource
    private userMapper userMapper;



    // 登录方法修改为返回包含用户信息的Map
    @PostMapping("/login")
    public Map<String, Object> login(@RequestBody User user, HttpSession session) {

        User dbUser = userMapper.getUserByNameAndPassword(user.getUsername(), user.getPassword());
        Map<String, Object> response = new HashMap<>();
        if (dbUser != null) {
            // 返回用户详细信息，包括ID和username
            session.setAttribute("Username",dbUser.getUsername());
            session.setAttribute("userId",dbUser.getUid());
            response.put("uid", dbUser.getUid());
            response.put("username", dbUser.getUsername());
            // 可以继续添加需要的字段，比如email等
        } else {
            // 如果用户登录失败，返回空的id和username
            response.put("uid", null);
            response.put("username", null);
        }
        return response;
    }

    // 检查邮箱是否存在的方法
    @PostMapping("/emailexist")
    public Map<String, Object> emailExist(@RequestBody User user) {
        Map<String, Object> response = new HashMap<>();
        User emailUser = userMapper.getUserByEmail(user.getEmail());
        if (emailUser != null) {
            response.put("uid", emailUser.getUid());
            response.put("email", emailUser.getEmail());
        } else {
            response.put("uid", null);
        }
        return response;
    }

    // 获取用户的旧密码
    @PostMapping("/oldpassword")
    public String oldPassword(@RequestBody String email) {
        return userMapper.getPasswordByEmail(email);
    }

    // 重置密码方法
    @PostMapping("/resetpassword")
    public void resetPassword(@RequestBody User user) {
        userMapper.updatePasswordByEmail(user.getEmail(), user.getPassword());
    }
}
