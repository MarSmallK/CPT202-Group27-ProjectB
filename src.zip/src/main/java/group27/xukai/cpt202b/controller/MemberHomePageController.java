package group27.xukai.cpt202b.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/member")
public class MemberHomePageController {

    // 处理会员个人主页的请求
    @GetMapping("/home")
    public String showHomePage() {
        return "MemberHomePage"; // 返回视图名，对应会员个人主页的HTML文件名
    }
}
