package group27.xukai.cpt202b.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@RequestMapping
@Controller
public class AllController {

    @GetMapping("/all")
    public String all(Model model) {
        model.addAttribute("attributeName", "attributeValue");
        return "all";
    }
}