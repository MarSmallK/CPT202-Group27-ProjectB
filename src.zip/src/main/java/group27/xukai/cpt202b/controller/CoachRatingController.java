package group27.xukai.cpt202b.controller;

import group27.xukai.cpt202b.service.CoachRatingService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;
import java.util.Map;

@Controller
public class CoachRatingController {

    private final CoachRatingService coachRatingService;

    public CoachRatingController(CoachRatingService coachRatingService) {
        this.coachRatingService = coachRatingService;
    }

    @GetMapping("/api/coachRatings")
    @ResponseBody
    public List<Map<String, Object>> getCoachRatings() {
        return coachRatingService.getAverageRatingsByCoach();
    }

    @GetMapping("/feedback/coachRating")
    public String showCoachRatings(Model model) {
        List<Map<String, Object>> ratings = coachRatingService.getAverageRatingsByCoach();
        model.addAttribute("ratings", ratings);
        return "CoachRating";
    }
}