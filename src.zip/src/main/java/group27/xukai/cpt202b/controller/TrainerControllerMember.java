package group27.xukai.cpt202b.controller;

import group27.xukai.cpt202b.entity.Trainer;
import group27.xukai.cpt202b.service.TrainerInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
public class TrainerControllerMember {

    @Autowired
    private TrainerInterface trainerInterface;
    //查询
    @RequestMapping("/TrainerDisplayMember")
    public ModelAndView Display(){
        ModelAndView modelAndView = new ModelAndView();
        List<Trainer>trainerList = trainerInterface.QueryAll();
        modelAndView.addObject("trainers",trainerList);
        modelAndView.setViewName("TrainerDisplayMember");
        return modelAndView;

    }

    @GetMapping("/TrainerDisplayMember")
    public String DisplayMember(){
        return "TrainerDisplayMember";
    }

}
