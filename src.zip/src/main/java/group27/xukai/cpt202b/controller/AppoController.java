package group27.xukai.cpt202b.controller;

import group27.xukai.cpt202b.entity.Appo;
import group27.xukai.cpt202b.repository.SelectRepository;
import group27.xukai.cpt202b.service.AppoInterface;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.beans.PropertyEditorSupport;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;


@Controller
public class AppoController {

    @Autowired
    private AppoInterface appoInterface;

    @Autowired
    private SelectRepository repository;



    @InitBinder
    public void initBinder(WebDataBinder binder) {
        binder.registerCustomEditor(Timestamp.class, new PropertyEditorSupport() {
            public void setAsText(String value) {
                try {
                    setValue(new Timestamp(new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").parse(value).getTime()));
                } catch (ParseException e) {
                    setValue(null);
                }
            }
        });
    }

    @PostMapping("/api/appointments")
//    @ResponseBody
    public ResponseEntity<?> getAppointmentsByUsername(HttpSession session) {
            // 使用修改后的 repository 方法
        Integer userId = (Integer) session.getAttribute("userId");
        if (userId == null) {
            // 用户未登录或会话已失效，可以重定向到登录页面或返回错误信息
            throw new IllegalStateException("User not logged in or session expired");
        }
         List<Object[]> rawAppointments = repository.findByUser((Integer) session.getAttribute("userId"));
            List<Appo> mjq = rawAppointments.stream().map(result -> {
                Appo appo = new Appo();
                appo.setAid((Integer) result[0]);
                appo.setTrainername((String) result[1]);
                appo.setStartTime((Timestamp) result[2]);
                appo.setFinishTime((Timestamp) result[3]);
                appo.setStatus((String) result[4]);
                appo.setTotalprice((Double) result[5]);
                appo.setUid((Integer) result[6]);
                appo.setCreateTime((Timestamp) result[7]);
                appo.setCancelTime((Timestamp) result[8]);
                return appo;
            }).collect(Collectors.toList());

            appo app= new appo(mjq);
            return ResponseEntity.ok(app);

    }


//    @GetMapping("/AppoManager")
//    public String displayAppoManager(Model model) {
//        List<Appo> appoList = appoInterface.QueryAll();
//        model.addAttribute("appos", appoList);
//        return "AppoDisplayManager"; // Display all appointments for managers
//    }

//    @GetMapping("/AppoMember")
//    public String displayAppoMember(Model model, HttpSession session) {
//        Integer uid = (Integer) session.getAttribute("userId");
//        if (uid != null) {
//            List<Appo> appoList = appoInterface.findByUser(uid);
//            model.addAttribute("appoList", appoList);
//
//            return "AppoDisplayMember2"; // 正确的视图名称返回
//        } else {
//            model.addAttribute("error", "User not logged in or invalid session");
//            return "errorPage"; // 根据需要调整返回的视图名称
//        }
//
//    }

//    @GetMapping("/AppoMember2")
//    public String displayAppoMember2(Model model, HttpSession session) {
//        Integer uid = (Integer) session.getAttribute("userId");
//
//        if (uid != null) {
//            List<Appo> appoList = appoInterface.findByUser(uid);
//
//
//            model.addAttribute("appos", appoList);
//
//            return "AppoDisplayMember2"; // 正确的视图名称返回
//
//        } else {
//            model.addAttribute("error", "User not logged in or invalid session");
//            return "errorPage"; // 根据需要调整返回的视图名称
//        }
//
//    }


    @RequestMapping("/delAppo")
    public ModelAndView delAppo(HttpServletRequest request) {
        int aid = Integer.parseInt(request.getParameter("aid"));
        boolean success = appoInterface.markAsDeleted(aid);
        if (success) {
            return new ModelAndView("redirect:/appo/xukai");
        } else {
            return new ModelAndView("errorPage", "error", "Failed to mark the appointment as deleted.");
        }
    }

    @RequestMapping("/updateAppo")
    public ModelAndView updateAppo(HttpServletRequest request) {
        int aid = Integer.parseInt(request.getParameter("aid"));
        boolean success = appoInterface.markAsFinished(aid);
        if (success) {
            return new ModelAndView("redirect:/appo/xukai");
        } else {
            return new ModelAndView("errorPage", "error", "Failed to mark the appointment as deleted.");
        }
    }

    @GetMapping("/addAppo")
    public ModelAndView addPageAppo(HttpServletRequest request,Model model) {
        model.addAttribute("appo", new Appo());

        return new ModelAndView("addAppo", "appomodel", model);

    }

    @PostMapping("/addAppointment")
    public ModelAndView someMethod(
            @RequestParam("startTime") @DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm") Date startTime,
            @RequestParam("finishTime") @DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm") Date finishTime,
            @RequestParam(value = "cancelTime", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm") Date cancelTime,
            @ModelAttribute Appo appo,
            RedirectAttributes redirectAttrs) {


        // Check for conflicts and add the appointment
        if (appoInterface.checkAppointmentConflict(appo.getTrainername(), startTime, finishTime)) {
            redirectAttrs.addFlashAttribute("error", "This time slot is already booked for the selected trainer, please choose a different time.");
            return new ModelAndView("redirect:/addAppo");
        }

        appo.setFinishTime(new Timestamp(startTime.getTime()));
        appo.setStartTime(new Timestamp(startTime.getTime()));
        if (appoInterface.Add(appo)) {

            redirectAttrs.addFlashAttribute("message", "Appointment added successfully!");
            return new ModelAndView("redirect:/appo/xukai");
        } else {
            redirectAttrs.addFlashAttribute("error", "Failed to add appointment.");
            return new ModelAndView("redirect:/addAppo");
        }
    }


//    @GetMapping("/sendAppoId")
//    public ModelAndView sendAppoId(HttpServletRequest request, Model model) {
//        int aid = Integer.parseInt(request.getParameter("aid"));
//        Appo appo = appoInterface.selectByPrimaryKey(aid);
//        model.addAttribute("appo", appo);
//        return new ModelAndView("EditAppo", "appomodel", model);
//    }
//
//    @PostMapping("/updateAppo")
//    public ModelAndView updateAppo(@ModelAttribute("appo") Appo appo, BindingResult result) {
//        if (result.hasErrors()) {
//            // 处理错误
//            return new ModelAndView("editForm");
//        }
//        appoInterface.Update(appo);
//        return new ModelAndView("redirect:/AppoMember");
//    }


    //发邮件
    @PostMapping("/sendAppointment")
    public String sendAppointment(@RequestParam("appoId") Integer appoId, RedirectAttributes redirectAttributes) {
        Appo appo = appoInterface.selectByPrimaryKey(appoId);
        if (appo != null) {
            appoInterface.sendAppo(appo);
            redirectAttributes.addFlashAttribute("message", "Appointment sent successfully!");
        } else {
            redirectAttributes.addFlashAttribute("error", "Appointment not found.");
        }
        return "redirect:/AppoDisplayManager";
    }

    @PostMapping("/sendA")
    @ResponseBody
    public String sendAppo(@RequestBody Appo appo) {
        try {
            appoInterface.sendAppo(appo);
            return "Appointment sent successfully!";
        } catch (Exception e) {
            return "Error sending appointment: " + e.getMessage();
        }
    }
    static class appo {
        private List<Appo> appointments;

        public appo(List<Appo> appointments) {
            this.appointments = appointments;
        }

        public List<Appo> getAppointments() {
            return appointments;
        }
    }

}
