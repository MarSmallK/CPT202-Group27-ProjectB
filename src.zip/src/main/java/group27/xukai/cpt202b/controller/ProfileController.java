package group27.xukai.cpt202b.controller;

import group27.xukai.cpt202b.service.ProfileService;
import group27.xukai.cpt202b.service.UserRequestPro;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ProfileController {

    private final ProfileService profileService;

    @Autowired
    public ProfileController(ProfileService profileService) {
        this.profileService = profileService;
    }

    @PostMapping("/profile/update")
    public String updateProfile(@RequestBody UserRequestPro userRequestPro, HttpServletRequest request) {
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("userId");  // Get userId from session

        System.out.println(userRequestPro);

        if (userId != null) {
            profileService.updateProfile(userRequestPro.getFirstName(), userRequestPro.getLastName(), userRequestPro.getEmail(), userRequestPro.getGender(),userRequestPro.getPhone(), userRequestPro.getAge(), userRequestPro.getFitnessPreference(),userId);
            return "Profile updated successfully.";
        } else {
            return "Error: User not logged in.";
        }
    }
}
