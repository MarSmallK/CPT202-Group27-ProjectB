package group27.xukai.cpt202b.controller;

import group27.xukai.cpt202b.entity.Planrecord;
import group27.xukai.cpt202b.service.PlanrecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/member/fitnessplan")
public class PlanrecordController {
    @Autowired
    private PlanrecordService planrecordService;

//    @PostMapping("saveRecharge")
//    public ResponseEntity<String> saveRecharge(@RequestBody Map<String, Integer> requestBody, HttpSession session) {
//        Integer rechargeAmount = requestBody.get("amount");
//        String userName = (String) session.getAttribute("userName");
//        Planrecord newRecord = new Planrecord();
//        newRecord.setUsername(userName);
//        // 更新会员的时间信息
//        LocalDateTime startTime = LocalDateTime.now();
//
//        // 保存新的 Planrecord 对象到数据库中
//        planrecordService.saveRecord(newRecord);
//        planrecordService.addRecord(startTime,rechargeAmount,userName);
//        return ResponseEntity.ok("Member's recharge record updated successfully!");
//    }


    @GetMapping("/ViewRecord")
    public String getRecord(Model model) {
//        String  userName = (String) session.getAttribute("userName");

        // 获取会员数据
        List<Planrecord> planrecord = planrecordService.getPlanrecordData();
        // 将更新后的会员数据传递到前端
        model.addAttribute("planRecord", planrecord);

        // 返回模板名称，Thymeleaf 将根据模板名称渲染页面
        return "MemberCostRecord";
    }
}
