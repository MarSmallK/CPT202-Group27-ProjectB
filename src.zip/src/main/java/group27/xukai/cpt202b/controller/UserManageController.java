package group27.xukai.cpt202b.controller;

import group27.xukai.cpt202b.entity.User;
import group27.xukai.cpt202b.repository.UserRepo;
import group27.xukai.cpt202b.service.serviceImpl.UserManageServiceImpl;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Map;

@Controller
public class UserManageController {

    @Autowired
    private UserManageServiceImpl userManageServiceImpl;

    @Autowired
    private UserRepo userRepo;


    @GetMapping("/user/all")
    public String allUser(
            @RequestParam(defaultValue = "0") int page, // Page number
            @RequestParam(defaultValue = "10") int size, // Page size
            Model model) {

        // Fetch paginated users
        Page<User> userPage = userManageServiceImpl.findAll(PageRequest.of(page, size));

        // Check if the page is out of bounds
        if (page < 0 || page >= userPage.getTotalPages()) {
            page = 0; // Reset to first page or handle appropriately
        }

        // Add attributes to model
        model.addAttribute("users", userPage.getContent());
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", userPage.getTotalPages());

        long totalUsersCount = userRepo.count(); // 获取总用户数量
        model.addAttribute("totalUsersCount", totalUsersCount);

        return "UserManage";
    }

    // Delete a user
    @RequestMapping("/user/del")
    public ModelAndView deleteUser(HttpServletRequest request) {
        int userId = Integer.parseInt(request.getParameter("uid"));
        userManageServiceImpl.deleteById(userId);
        return new ModelAndView("redirect:/user/all");
    }

//    @RequestMapping("/user/del")
//    public ModelAndView deleteUser(HttpServletRequest request, RedirectAttributes redirectAttributes) {
//        int userId = Integer.parseInt(request.getParameter("uid"));
//        userManageServiceImpl.deleteById(userId);
//        redirectAttributes.addFlashAttribute("message", "User deleted successfully!");
//        return new ModelAndView("redirect:/user/all");
//    }

    // Display the form to add a new user
    @GetMapping("/user/add")
    public String addPage(Model model) {
//    public ModelAndView addUserPage(Model model) {
        model.addAttribute("user", new User());
        return "UserAdd";
//        return new ModelAndView("UserAdd", "user", model);
    }

//    // Submit the form to add a new user
//    @PostMapping("/user/add")
//    public ModelAndView addUser(User user) {
//        userManageService.add(user);
//        return new ModelAndView("redirect:/user/all");
//    }

    @PostMapping("/user/add")
    public String addUser(@ModelAttribute("user") User user, BindingResult result, RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) {
            // Handle errors, possibly adding error messages to the model
            return "UserAdd";  // Return to the form with errors
        }
        try {
            userManageServiceImpl.add(user);
            redirectAttributes.addFlashAttribute("successMessage", "User added successfully!");
            return "redirect:/user/all";  // Redirect to prevent duplicate submissions
        } catch (Exception e) {
            // Log exception and handle error
            result.rejectValue("username", "error.user", "An error occurred: " + e.getMessage());
            return "UserAdd";  // Stay on the current page to display the error
        }
    }

    // Endpoint to check if a username already exists
    @PostMapping("/user/check_username")
    public boolean checkUsername(@RequestBody Map<String, String> payload) {
        String username = payload.get("username");
        return !userRepo.existsByUsername(username);
    }

    // Endpoint to check if an email already exists
    @PostMapping("/user/check_email")
    public boolean checkEmail(@RequestBody Map<String, String> payload) {
        String email = payload.get("email");
        return !userRepo.existsByEmail(email);
    }


    // Display the form to edit a user
//    @GetMapping("/user/editPage/{uid}")
//    public ModelAndView editUserPage(HttpServletRequest request, Model model) {
//        int userId = Integer.parseInt(request.getParameter("uid"));
//        Optional<User> userOpt = userManageService.findById(userId);
//        userOpt.ifPresent(user -> model.addAttribute("user", user));
//        return new ModelAndView("userEdit", "user", model);
//    }

//    @GetMapping("/user/editPage/")
//    public String editUserPage(HttpSession session, Model model) {
//        Integer userId = (Integer) session.getAttribute("userId");
//@GetMapping("/user/editPage/{uid}")
//public String editUserPage(@PathVariable("uid") Integer uid, Model model) {
//        Optional<User> userOpt = userManageServiceImpl.findById(uid);
//        if (userOpt.isPresent()) {
//            model.addAttribute("user", userOpt.get());
//            return "userEdit";
//        } else {
//            // You can redirect to a general page or show an error message
//            return "redirect:/user/all"; // Redirects back to the user list if the user is not found
//        }
//    }

    // Submit the form to update a user
    @PostMapping("/user/update")
    public ModelAndView updateUser(User user) {
        user.setType(0);
        userManageServiceImpl.update(user);
        return new ModelAndView("redirect:/memberindex");
    }

}
