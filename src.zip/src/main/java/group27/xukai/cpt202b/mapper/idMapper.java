package group27.xukai.cpt202b.mapper;

import group27.xukai.cpt202b.entity.idAppointment;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface idMapper {

    @Select("SELECT * FROM i_appointment WHERE appointmentID = #{id}")
    idAppointment getAppointmentById(@Param("id") Integer id);

    //取消预约
    @Delete("DELETE FROM i_appointment WHERE appointmentID = #{id}")
    void deleteAppointmentById(@Param("id") Integer id);


}
