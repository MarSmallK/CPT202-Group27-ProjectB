package group27.xukai.cpt202b.mapper;

import group27.xukai.cpt202b.entity.Appo;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;

@Component
@Mapper
public interface AppoMapper {

    @Select("SELECT COUNT(*) FROM appo WHERE trainername = #{trainername} AND (start_time < #{finishTime} AND finish_time > #{startTime})")
    int countOverlappingAppointments(@Param("trainername") String trainername, @Param("startTime") Date startTime, @Param("finishTime") Date finishTime);

    @Select("SELECT COUNT(*) FROM appo WHERE trainername = #{trainername} AND NOT (finish_time <= #{startTime} OR start_time >= #{finishTime})")
    int countByTrainerAndTime(@Param("trainername") String trainername, @Param("startTime") Date startTime, @Param("finishTime") Date finishTime);

    @Delete("DELETE FROM appo WHERE aid = #{aid}")
    int deleteByPrimaryKey(Integer aid);

    @Insert("INSERT INTO appo (uid, trainername, finish_time, start_time, totalprice, status) " +
            "VALUES (#{uid}, #{trainername}, #{finishTime}, #{startTime}, #{totalprice}, #{status})")
    @Options(useGeneratedKeys = true, keyProperty = "aid")
    int insert(Appo record);

    @Insert("INSERT INTO appo (uid, trainername, start_time, totalprice, status) " +
            "VALUES (#{uid}, #{trainername}, #{startTime}, #{totalprice}, #{status})")
    int insertSelective(Appo record);

    @Select("SELECT * FROM appo WHERE aid = #{aid}")
    Appo selectByPrimaryKey(Integer appoId);

    @Update("UPDATE appo SET uid = #{uid}, trainername = #{trainername}, start_time = #{startTime}, " +
            "totalprice = #{totalprice}, status = #{status} WHERE aid = #{aid}")
    int updateByPrimaryKeySelective(Appo record);

    @Update("UPDATE appo SET uid = #{uid}, trainername = #{trainername}, start_time = #{startTime}, " +
            "totalprice = #{totalprice}, status = #{status} WHERE aid = #{aid}")
    int updateByPrimaryKey(Appo record);

    @Select("SELECT * FROM appo")
    List<Appo> QueryAll();

    @Select("SELECT * FROM appo WHERE uid = #{uid}")
    List<Appo> findByUser(int uid);

    @Select("SELECT * FROM appo WHERE aid = #{aid}")
    Appo findByAid(int aid);

    @Select("SELECT * FROM appo WHERE trainername = #{trainerId}")
    List<Appo> findByTrainer(int trainerId);

    @Update("UPDATE appo SET totalprice = #{totalprice} WHERE aid = #{aid}")
    void updatePriceByAppoId(@Param("aid") int appoId, @Param("totalprice") double totalprice);

    @Update("UPDATE appo SET status = #{status} WHERE aid = #{aid}")
    int updateStatusById(@Param("aid") int aid, @Param("status") String status);

    @Update("UPDATE appo SET status = #{status}, cancel_time = CURRENT_TIMESTAMP WHERE aid = #{aid}")
    int updateStatusAndCancelTimeById(@Param("aid") int aid, @Param("status") String status);

    @Update("UPDATE appo SET status = #{status}, cancel_time = CURRENT_TIMESTAMP WHERE aid = #{aid}")
    int updateStatusFinishById(@Param("aid") int aid, @Param("status") String status);


}

