package group27.xukai.cpt202b.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

@Mapper
public interface CoachRatingMapper {
    @Select("SELECT f.coachid as coachId, AVG(f.rating) as averageRating, t.name as name FROM feedback f LEFT JOIN trainer t ON f.coachid = t.trainer_ID GROUP BY f.coachid")
    List<Map<String, Object>> getAverageRatingsByCoach();
}