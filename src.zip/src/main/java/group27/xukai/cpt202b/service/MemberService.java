package group27.xukai.cpt202b.service;

import group27.xukai.cpt202b.entity.Member;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.time.LocalDateTime;
import java.util.List;

public interface MemberService {
    int getMemberBalance(int userId);
    String getPlanLevel(int userId);
    LocalDateTime getStartTime(int userId);
    void updateMemberWithFitnessPlan(String planLevel, String planDate, int userId);
    void updateMemberBalance(Integer balance, int userId);
    void updateMemberPurchasePlanId(Integer purchasePlanId, int userId);

    void updateMemberState(int userId, String planState);

    void updateTime(int userId, LocalDateTime startTime, LocalDateTime endTime);

    List<Member> getMemberData();
    void clearMemberData(int userId);

    void updateUserId(int userId);

    void saveMember(Member member);
    Member getMemberByUserId(int userId);
    Page<Member> findMembersWithFitnessPlan(Pageable pageable);
}