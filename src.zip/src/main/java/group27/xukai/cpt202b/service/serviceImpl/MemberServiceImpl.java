package group27.xukai.cpt202b.service.serviceImpl;

import group27.xukai.cpt202b.repository.MemberRepository;
import group27.xukai.cpt202b.repository.UserRepository;
import group27.xukai.cpt202b.entity.Member;
import group27.xukai.cpt202b.service.MemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;

@Service
public class MemberServiceImpl implements MemberService {

    private final MemberRepository memberRepository;


    @Autowired
    public MemberServiceImpl(MemberRepository memberRepository, UserRepository userRepository) {
        this.memberRepository = memberRepository;

    }

    @Override
    public List<Member> getMemberData() {
        List<Member> members = memberRepository.findAll();
        if (members.isEmpty()){
            return Collections.emptyList();
        }
        return members;
    }

    @Transactional
    @Override
    public void clearMemberData(int userId) {
        memberRepository.clearMemberData(userId);
    }

    @Override
    public void updateUserId(int userId) {
        Member member = memberRepository.findByUserId(userId);
        if (member!= null){
            member.setUserId(userId);
            memberRepository.save(member);
        }
    }

    @Override
    public void saveMember(Member member) {
        memberRepository.save(member);
    }

    @Override
    public Member getMemberByUserId(int userId) {
        Member member = memberRepository.findByUserId(userId);
        return member;
    }

    @Override
    public Page<Member> findMembersWithFitnessPlan(Pageable pageable) {
        // 编写自定义查询，获取购买了健身计划的会员数据
        return memberRepository.findByPurchasePlanIdIsNotNull(pageable);
    }

    @Override
    public int getMemberBalance(int userId) {
        Integer balance = memberRepository.getBalanceByUserId(userId);
        if (balance != null) {
            return balance;
        } else {
            // 这里可以根据实际情况处理空值，比如返回一个默认值或者抛出异常
//            throw new RuntimeException("Balance is null for user ID: " + userId);
            return 0;
        }
    }


    @Override
    public String getPlanLevel(int userId) {
        return memberRepository.getPlanLevel(userId);
    }

    @Override
    public LocalDateTime getStartTime(int userId) {
        return memberRepository.getStartTimeByUserId(userId);
    }

    @Override
    public void updateMemberWithFitnessPlan(String planLevel, String planDate, int userId) {
        Member member = memberRepository.findByUserId(userId);
        if (member != null) {
            member.setPlanLevel(planLevel);
            member.setPlanDate(planDate);
            memberRepository.save(member);
        }
    }

    @Override
    public void updateMemberBalance(Integer balance, int userId) {
        Member member = memberRepository.findByUserId(userId);
        if (member != null) {
            member.setBalance(balance);
            memberRepository.save(member);
        }
    }

    @Override
    public void updateMemberPurchasePlanId(Integer purchasePlanId, int userId) {
        Member member = memberRepository.findByUserId(userId);
        if (member != null) {
            member.setPurchasePlanId(purchasePlanId);
            memberRepository.save(member);
        }
    }

    @Override
    public void updateMemberState(int userId, String planState) {
        Member member = memberRepository.findByUserId(userId);
        if (member != null) {
            member.setPlanState(planState);
            // 保存更新后的用户信息到数据库中
            memberRepository.save(member);
        }
    }

    @Override
    public void updateTime(int userId, LocalDateTime startTime, LocalDateTime endTime) {
        Member member = memberRepository.findByUserId(userId);
        if (member != null) {
            // 更新用户的开始时间和结束时间
            member.setStartTime(startTime);
            member.setEndTime(endTime);
            // 保存更新后的用户信息到数据库中
            memberRepository.save(member);

        }
    }



}