package group27.xukai.cpt202b.service;

import group27.xukai.cpt202b.entity.User;
import group27.xukai.cpt202b.repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserManageServiceImpl implements UserManageService{

    @Autowired
    private UserRepo userRepo;


    @Override
    // Retrieve all users
    public List<User> findAll() {
        return userRepo.findAll();
    }

    @Override
    // Retrieve a user by primary key
    public Optional<User> findById(int uid) {
        return userRepo.findById(uid);
    }

    @Override
    // Add a new user
    public User add(User user) {
        return userRepo.save(user);
    }

    @Override
    // Update an existing user
    public User update(User user) {
        return userRepo.save(user);
    }

    @Override
    // Delete a user by primary key
    public void deleteById(int uid) {
        userRepo.deleteById(uid);
    }

    @Override
    public Page<User> findAll(Pageable pageable) {
        return userRepo.findAll(pageable);
    }


}
