package group27.xukai.cpt202b.service;

import group27.xukai.cpt202b.entity.idAppointment;

public interface idService {

    void cancel(idAppointment appointment);

//    void getAppointmentsByMemberName(memberName);

}
