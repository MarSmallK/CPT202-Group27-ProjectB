package group27.xukai.cpt202b.service.serviceImpl;

import group27.xukai.cpt202b.entity.User;
import group27.xukai.cpt202b.repository.UserRepo;
import group27.xukai.cpt202b.service.UserManageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserManageServiceImpl implements UserManageService {

    @Autowired
    private UserRepo userRepo;

    @Override
    // Retrieve all users
    public List<User> findAll() {
        return userRepo.findAll();
    }

    @Override
    // Retrieve a user by primary key
    public Optional<User> findById(int uid) {
        return userRepo.findById(uid);
    }

    @Override
    // Add a new user
    public User add(User user) {
        return userRepo.save(user);
    }

    @Override
    // Update an existing user
    public User update(User user) {
        return userRepo.save(user);
    }

    @Override
    // Delete a user by primary key
    public void deleteById(int uid) {
        userRepo.deleteById(uid);
    }

    @Override
    public Page<User> findAll(Pageable pageable) {
        return userRepo.findAll(pageable);
    }

//    public List<User> searchUsersByUsername(String username) {
//        return userRepo.findByUsernameContainingIgnoreCase(username);
//    }
//
//    public List<User> searchUsersByEmail(String email) {
//        return userRepo.findByEmailContainingIgnoreCase(email);
//    }
//
//    public List<User> searchUsersByGender(String gender) {
//        return userRepo.findByGenderContainingIgnoreCase(gender);
//    }

//    @Override
//    public List<User> searchUsers(String field, String query) {
//        // 这里将根据field的值来决定使用哪个属性进行搜索
//        // 示例: 如果field是'email', 使用email来搜索
//        // 使用Spring Data JPA的Specification或Query来实现动态查询
//        return userRepo.findByAttribute(field, query);
//    }

}
