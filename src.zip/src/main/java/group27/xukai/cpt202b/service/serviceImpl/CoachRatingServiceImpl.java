package group27.xukai.cpt202b.service.serviceImpl;

import group27.xukai.cpt202b.mapper.CoachRatingMapper;
import group27.xukai.cpt202b.service.CoachRatingService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class CoachRatingServiceImpl implements CoachRatingService {

    private final CoachRatingMapper coachRatingMapper;

    public CoachRatingServiceImpl(CoachRatingMapper coachRatingMapper) {
        this.coachRatingMapper = coachRatingMapper;
    }

    @Override
    public List<Map<String, Object>> getAverageRatingsByCoach() {
        return coachRatingMapper.getAverageRatingsByCoach();
    }
}