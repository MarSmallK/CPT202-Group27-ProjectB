package group27.xukai.cpt202b.service.serviceImpl;

import group27.xukai.cpt202b.repository.PlanrecordRepository;
import group27.xukai.cpt202b.entity.Planrecord;
import group27.xukai.cpt202b.service.PlanrecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;

@Service
public class PlanrecordServiceImpl implements PlanrecordService {
    private final PlanrecordRepository planrecordRepository;


    @Autowired
    public PlanrecordServiceImpl(PlanrecordRepository planrecordRepository) {
        this.planrecordRepository = planrecordRepository;

    }
    @Override
    public void addRecord(LocalDateTime purchaseDate, Integer rechargeAmount, String username) {
        Planrecord newRecord = new Planrecord();
        newRecord.setPurchaseDate(purchaseDate);
        newRecord.setPrice(rechargeAmount);
        newRecord.setUsername(username);
        planrecordRepository.save(newRecord);
    }

    @Override
    public void saveRecord(Planrecord planrecord) {
        planrecordRepository.save(planrecord);
    }

    @Override
    public List<Planrecord> getPlanrecordData() {
        List<Planrecord> planrecords = planrecordRepository.findAll();
        if (planrecords.isEmpty()){
            return Collections.emptyList();
        }
        return planrecords;
    }
}
