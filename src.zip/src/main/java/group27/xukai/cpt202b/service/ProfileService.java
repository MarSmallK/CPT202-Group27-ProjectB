package group27.xukai.cpt202b.service;

import group27.xukai.cpt202b.entity.Profile;
import group27.xukai.cpt202b.repository.ProfileRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProfileService {
    private final ProfileRepository profileRepository;

    @Autowired
    public ProfileService(ProfileRepository profileRepository) {
        this.profileRepository = profileRepository;
        System.out.println(profileRepository);
    }

    public void updateProfile(String firstName, String lastName, String email, String gender, String phone, int age, String fitnessPreference,Integer userId) {
        Profile profile = new Profile();
        profile.setUserId(userId);  // Set the userId obtained from the session
        profile.setFirstName(firstName);
        profile.setLastName(lastName);
        profile.setEmail(email);
        profile.setGender(gender);
        profile.setPhone(phone);
        profile.setAge(age);
        profile.setFitnessPreference(fitnessPreference);

        profileRepository.save(profile);
    }
}
