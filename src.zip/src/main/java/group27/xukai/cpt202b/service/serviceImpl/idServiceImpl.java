package group27.xukai.cpt202b.service.serviceImpl;

import group27.xukai.cpt202b.mapper.idMapper;
import group27.xukai.cpt202b.entity.idAppointment;
import group27.xukai.cpt202b.service.idService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class idServiceImpl implements idService {
    @Autowired
    private idMapper idMapper;

    @Transactional
    @Override
    public void cancel(idAppointment appointment) {

        LocalDateTime now = LocalDateTime.now(); // 获取当前时间
        idAppointment existingAppointment = idMapper.getAppointmentById(appointment.getAppointmentID());

        if (existingAppointment.getAppointedTime().isBefore(now)) {
            throw new IllegalStateException("Sorry, you cannot cancel your appointment just before the lesson");
        } else {
            idMapper.deleteAppointmentById(appointment.getAppointmentID());
        }

        idMapper.deleteAppointmentById(appointment.getAppointmentID());
    }

}


