package group27.xukai.cpt202b.service;

import group27.xukai.cpt202b.Common.Result;
import group27.xukai.cpt202b.entity.ServiceType;
import group27.xukai.cpt202b.repository.ServiceTypeRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ServiceTypeService {
    
    @Autowired
    private ServiceTypeRepo serviceTypeRepo;

    // add a new service
    public Result<?> addService_M(ServiceType service) {
        serviceTypeRepo.save(service);
        return Result.success("", "Service added succssfully!");
    }
    
    // get all services
    public List<ServiceType> getAllServiceTypes() {
        return serviceTypeRepo.findAll();
    }

    // public void updateService(java.security.Provider.Service service) {
    //     serviceTypeRepo.save(service);
    // }

    // edit service
    public void updateServiceType(ServiceType service) {
        serviceTypeRepo.save(service);
    }

    public void deleteServiceTypeById(Integer sid) {
        serviceTypeRepo.deleteById(sid);
    }

    public List<ServiceType> searchServiceTypeByName_M(String name) {
        return serviceTypeRepo.findByServiceNameContaining(name);
    }

}