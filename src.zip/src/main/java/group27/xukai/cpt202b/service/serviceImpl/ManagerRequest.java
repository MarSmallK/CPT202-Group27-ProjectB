package group27.xukai.cpt202b.service.serviceImpl;

public class ManagerRequest {
        private String managerID;
        private String password;

    public String getManagerID() {
        return managerID;
    }

    public void setManagerID(String managerID) {
        this.managerID = managerID;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
