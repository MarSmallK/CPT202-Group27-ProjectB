package group27.xukai.cpt202b.service;

public class UserRequestPro {
    private String firstName;
    private String lastName;
    private String email;
    private String gender;
    private String phone;
    private Integer age;
    private String fitnessPreference;

    // Getters and setters
    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;

    }
    public String getLastName() {
        return lastName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }

    public String getGender() {
        return gender;
    }
    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getPhone() {
        return phone;
    }
    public void setPhone(String phone) {
        this.phone = phone;
    }
    public Integer getAge() {
        return age;
    }
    public void setAge(Integer age) {
        this.age = age;
    }
    public String getFitnessPreference() {
        return fitnessPreference;
    }
    public void setFitnessPreference(String fitnessPreference) {
        this.fitnessPreference = fitnessPreference;
    }

    @Override
    public String toString() {
        return "UserRequestPro{" +
                "firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", email='" + email + '\'' +
                ", gender='" + gender + '\'' +
                ", phone='" + phone + '\'' +
                ", age=" + age +
                ", fitnessPreference='" + fitnessPreference + '\'' +
                '}';
    }
}

