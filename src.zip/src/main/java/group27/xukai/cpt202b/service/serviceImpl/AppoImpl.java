
package group27.xukai.cpt202b.service.serviceImpl;

import group27.xukai.cpt202b.entity.Appo;
import group27.xukai.cpt202b.exception.ServiceException;
import group27.xukai.cpt202b.mapper.AppoMapper;
import group27.xukai.cpt202b.service.AppoInterface;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Service
public class AppoImpl implements AppoInterface {

    @Autowired
    private AppoMapper appoMapper;


    @Autowired
    private JavaMailSender mailSender;

    public static final Logger logger = LoggerFactory.getLogger(AppoImpl.class);


    @Override
    public List<Appo> findByUser(int uid) {
        return appoMapper.findByUser(uid); // Implementation to call mapper
    }

    public boolean checkAppointmentConflict(String trainername, Date startTime, Date finishTime) {
        return appoMapper.countByTrainerAndTime(trainername, startTime, finishTime) > 0;
    }


    @Transactional
    @Override
    public boolean Add(Appo appo) {
        // Check for overlapping appointments
        if (appoMapper.countOverlappingAppointments(appo.getTrainername(), appo.getStartTime(), appo.getFinishTime()) > 0) {
            return false; // There is an overlap, so do not add the appointment
        }

        if (appo.getStatus() == null || appo.getStatus().isEmpty()) {
            appo.setStatus("pending"); // 设置默认值
        }
        return appoMapper.insert(appo) > 0;
    }

//    @Override
//    public List<Appo> findByUserUsernameContaining(String username) {
//        return appoMapper.findByUserUsernameContaining(username);
//    }


    // 查询
    public List<Appo> QueryAll() {
        List<Appo> appos = appoMapper.QueryAll();
        return appos;
    }

    // 查询
    public Appo selectByPrimaryKey(Integer uid) {
        Appo appos = appoMapper.selectByPrimaryKey(uid);
        return appos;
    }


//    // 新增
//    public boolean Add(Appo appo) {
//        int i = appoMapper.insert(appo);
//        if (i > 0)
//            return true;
//        else
//            return false;
//    }

    // 删除
    public boolean Del(int aid) {
        int i = appoMapper.deleteByPrimaryKey(aid);
        if (i > 0)
            return true;
        else
            return false;
    }



    // 更新
    public boolean Update(Appo appo) {
        int i = appoMapper.updateByPrimaryKey(appo);
        if (i > 0)
            return true;
        else
            return false;
    }

    @Override
    public void sendAppo(Appo appo) {

    }



    @Override
    public List<Appo> findByGroomer(int gid) {
        return null;
    }

    @Override
    public void updatePriceByAppoId(int aid, String price) {

    }

    @Override
    public void SendAppo(Appo appo) {

    }

    // 发送通知
    // Sending appo method updated
    public void sendNot(Appo appo) {
        try {
            // Attempt to send email first
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom("2667952546@qq.com");
//            message.setTo(appo.getTrainerid());
//            message.setSubject(appo.getAppoid());
//            message.setText();
            mailSender.send(message);

            // Only insert into database if email was successfully sent
            try {
                appoMapper.insert(appo);
            } catch (DuplicateKeyException e) {
                logger.error("Failed to insert notification, duplicate ID: {}", appo.getAid(), e);
                // Optionally, rethrow or handle this as needed
            }

        } catch (MailException e) {
            logger.error("Email sending failed", e);
            throw new ServiceException("Email sending failed", e);
        }
    }

//    @Override
//    public boolean markAsDeleted(int aid) {
//        return appoMapper.updateStatusById(aid, "deleted") > 0;
//    }

    @Override
    public boolean markAsDeleted(int aid) {
        return appoMapper.updateStatusAndCancelTimeById(aid, "deleted") > 0;
    }


    @Override
    public boolean markAsFinished(int aid) {
        return appoMapper.updateStatusFinishById(aid, "finished") > 0;
    }

}
