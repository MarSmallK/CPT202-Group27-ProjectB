package group27.xukai.cpt202b.service;

import group27.xukai.cpt202b.entity.Planrecord;

import java.time.LocalDateTime;
import java.util.List;

public interface PlanrecordService {
    void addRecord(LocalDateTime purchaseDate, Integer rechargeAmount, String username);
    void saveRecord(Planrecord planrecord);
    List<Planrecord> getPlanrecordData();
}
