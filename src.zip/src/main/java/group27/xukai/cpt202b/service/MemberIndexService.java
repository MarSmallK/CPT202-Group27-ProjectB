package group27.xukai.cpt202b.service;

import group27.xukai.cpt202b.entity.User;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public interface MemberIndexService {
    List<User> getUserData();
    User getUserById(Integer userId);
}
