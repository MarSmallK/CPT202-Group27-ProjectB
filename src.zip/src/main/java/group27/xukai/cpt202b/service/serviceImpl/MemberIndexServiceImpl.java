package group27.xukai.cpt202b.service.serviceImpl;

import group27.xukai.cpt202b.entity.User;
import group27.xukai.cpt202b.repository.MemberIndexRepository;
import group27.xukai.cpt202b.service.MemberIndexService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MemberIndexServiceImpl implements MemberIndexService {

    private final MemberIndexRepository memberIndexRepository;

    @Autowired
    public MemberIndexServiceImpl(MemberIndexRepository memberIndexRepository) {
        this.memberIndexRepository = memberIndexRepository;
    }

    @Override
    public List<User> getUserData() {
      return memberIndexRepository.findAll();
    }
    @Override
    public User getUserById(Integer userId) {
        // 返回给定 userId 对应的用户对象
        return memberIndexRepository.findById(userId).orElse(null);
    }
}
