package group27.xukai.cpt202b.service;

import group27.xukai.cpt202b.entity.Appo;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public interface AppoInterface {

    public boolean checkAppointmentConflict(String trainername, Date startTime, Date finishTime);
    // 查询所有
    List<Appo> QueryAll();
    // 按主键Id查询
    Appo selectByPrimaryKey(Integer aid);
    // 新增
    boolean Add(Appo appo);
    // 删除
    boolean Del(int aid);
    // 修改
    boolean Update(Appo appo);
    // 发送通知
    void sendAppo(Appo appo);


    // 根据用户ID查询

    List<Appo> findByUser(int uid);

    // 更新状态为"deleted"而不是实际删除
    boolean markAsDeleted(int aid);

    boolean markAsFinished(int aid);
//    // 根据用户名模糊查询
//    List<Appo> findByUserUsernameContaining(String username);
    // 根据培训师ID查询
    List<Appo> findByGroomer(int gid);
    // 更新价格
    void updatePriceByAppoId(int aid, String totalprice);

    void SendAppo(Appo appo);

}
