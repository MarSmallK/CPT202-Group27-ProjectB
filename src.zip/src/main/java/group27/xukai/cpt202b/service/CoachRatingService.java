package group27.xukai.cpt202b.service;

import java.util.List;
import java.util.Map;

public interface CoachRatingService {
    List<Map<String, Object>> getAverageRatingsByCoach();
}