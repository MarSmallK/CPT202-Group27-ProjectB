package group27.xukai.cpt202b.entity;

import lombok.Data;

import jakarta.persistence.*;

@Data
@Entity
public class ServiceType {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(columnDefinition = "int(7)")
    private Integer sid;

    @Column(columnDefinition = "varchar(50)", nullable = true)
    private String serviceName;
    
    @Column(columnDefinition = "int(7)", nullable = true)
    private Integer serviceTime;

    @Column(columnDefinition = "int(7)", nullable = true)
    private Integer basicPrice;

    public ServiceType(String serviceName, int serviceTime, int basicPrice) {
        serviceName = serviceName;
        serviceTime = serviceTime;
        basicPrice = basicPrice;
    }

    public ServiceType() {
    }

    public ServiceType(Integer sid) {
        this.sid = sid;
    }

    

}
