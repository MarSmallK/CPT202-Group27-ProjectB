package group27.xukai.cpt202b.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Getter
@Setter
@Data
@Table(name = "schedule")
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Schedule {
    @Id
   // @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id")
    private Long id;
    @Column(name = "date")
    private String date;
    @Column(name = "time")
    private String time;
    @Column(name = "event")
    private String event;
    @Column(name = "plan")
    private String plan;
    @Column(name = "completion")
    private String completion;
}