package group27.xukai.cpt202b.entity;

public class Message {
    
}
