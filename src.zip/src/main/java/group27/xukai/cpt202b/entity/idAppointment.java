package group27.xukai.cpt202b.entity;

import java.time.LocalDateTime;

public class idAppointment {

    private Integer appointmentID;
    private LocalDateTime appointedTime;

    public idAppointment() {
    }

    public idAppointment(Integer appointmentID, LocalDateTime appointedTime) {
        this.appointmentID = appointmentID;
        this.appointedTime = appointedTime;
    }

    public Integer getAppointmentID() {
        return appointmentID;
    }

    public void setAppointmentID(Integer appointmentID) {
        this.appointmentID = appointmentID;
    }

    public LocalDateTime getAppointedTime() {
        return appointedTime;
    }

    public void setAppointedTime(LocalDateTime appointedTime) {
        this.appointedTime = appointedTime;
    }
}
