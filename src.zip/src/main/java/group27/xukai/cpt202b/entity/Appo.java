package group27.xukai.cpt202b.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import org.springframework.format.annotation.DateTimeFormat;

import java.sql.Timestamp;

@Entity
@Table(name = "appo")
public class Appo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "aid")
    private int aid;

    @Column(name = "trainername")
    private String trainername;

    @Column(name = "cancel_time")
//    @DateTimeFormat(pattern = "yyyy-MM-dd HH-mm-ss")
    private Timestamp cancelTime;

    @Column(name = "create_time")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH-mm-ss")
    private Timestamp createTime;

    @Column(name = "start_time")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH-mm-ss")
    private Timestamp startTime;

    @Column(name = "finish_time")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH-mm-ss")
    private Timestamp finishTime;

    @Column(name = "status")
    private String status;

    @Column(name = "totalprice")
    private Double totalprice;

    @Column(name = "uid")
    private int uid;

    // Getters and Setters

    public int getAid() {
        return aid;
    }

    public void setAid(int aid) {
        this.aid = aid;
    }

    public String getTrainername() {
        return trainername;
    }

    public void setTrainername(String trainername) {
        this.trainername = trainername;
    }

    public Timestamp getCancelTime() {
        return cancelTime;
    }

    public void setCancelTime(Timestamp cancelTime) {
        this.cancelTime = cancelTime;
    }

    public Timestamp getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Timestamp createTime) {
        this.createTime = createTime;
    }

    public Timestamp getFinishTime() {
        return finishTime;
    }

    public void setFinishTime(Timestamp finishTime) {
        this.finishTime = finishTime;
    }

    public Timestamp getStartTime() {
        return startTime;
    }

    public void setStartTime(Timestamp startTime) {
        this.startTime = startTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Double getTotalprice() {
        return totalprice;
    }

    public void setTotalprice(Double totalprice) {
        this.totalprice = totalprice;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }
}
