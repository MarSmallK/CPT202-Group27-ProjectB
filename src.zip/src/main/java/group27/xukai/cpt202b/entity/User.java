package group27.xukai.cpt202b.entity;

import jakarta.persistence.*;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.sql.Timestamp;


@Data
@Entity
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer uid;

    @Column(columnDefinition = "varchar(50)", nullable = false, unique = true)
    private String username;

    @Column(columnDefinition = "varchar(15)", nullable = false)
    private String password;

    @Column(columnDefinition = "tinyint", nullable = false)
    private Integer type;  // type 0: customer; type 1: manager

    @Column(columnDefinition = "Timestamp DEFAULT CURRENT_TIMESTAMP", nullable = true)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Timestamp registrationTime;

    @Column(name = "image_url", columnDefinition = "varchar(255) default '/assets/images/default-user.png'", nullable = true)
    private String imageURL;

    @Column(columnDefinition = "varchar(20) COMMENT 'may not only be male or female'", nullable = true)
    private String gender;

    @Column(columnDefinition = "varchar(11)", nullable = true)
    private String phoneNumber;

    @Column(columnDefinition = "varchar(100)", nullable = true)
    private String email;

    //TODO : default value = 0
    @Column(nullable = false, columnDefinition = "int(11) default 0")
    private Integer failedLoginAttempts = 0;



    public User(int uid) {
        this.uid=uid;
    }


    public User() {
    }

    public User(String username, String password, Integer type) {
        this.username = username;
        this.password = password;
        this.type = type;
    }


    public User(Integer uid, String username, String password, Integer type, Timestamp registrationTime,
                String imageURL, String gender, String phoneNumber, String email, Integer failedLoginAttempts) {
        this.uid = uid;
        this.username = username;
        this.password = password;
        this.type = type;
        this.registrationTime = registrationTime;
        this.imageURL = imageURL;
        this.gender = gender;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.failedLoginAttempts = failedLoginAttempts;
    }







}
