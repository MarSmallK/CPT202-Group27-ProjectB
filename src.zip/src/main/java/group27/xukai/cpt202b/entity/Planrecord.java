package group27.xukai.cpt202b.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@EnableJpaRepositories
@Table(name = "record")
public class Planrecord {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Id")
    private int Id;

    @Column(name = "price")
    private int price;

    @Column(name = "purchasedate")
    private LocalDateTime purchaseDate;

    @Column(name = "username")
    private String username;

}
