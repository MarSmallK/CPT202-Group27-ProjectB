package group27.xukai.cpt202b.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.time.LocalDate;

@Data
@Entity   //表示这个类是一个实体类
@Table(name = "member")
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class PlanData {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Id")
    private int Id;

    @Column(name = "start_time")
    private LocalDate planDate;

    @Column(name = "plan_level")
    private String planLevel;

    @Column(name = "balance")
    private int planPrice;

}


