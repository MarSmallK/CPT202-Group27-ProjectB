package group27.xukai.cpt202b.repository;

import group27.xukai.cpt202b.entity.Profile;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface ProfileRepository extends JpaRepository<Profile, Long>  {

}


