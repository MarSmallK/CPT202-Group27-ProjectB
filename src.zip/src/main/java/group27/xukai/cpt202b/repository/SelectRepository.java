package group27.xukai.cpt202b.repository;

import group27.xukai.cpt202b.entity.Appo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SelectRepository extends JpaRepository<Appo, Long> {
    @Query(value = "SELECT aid, trainername, start_time, finish_time, status, totalprice, uid, create_time, cancel_time FROM appo WHERE uid = :uid", nativeQuery = true)
    List<Object[]> findByUser(int uid);
}