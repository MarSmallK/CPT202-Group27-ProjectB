package group27.xukai.cpt202b.repository;

import group27.xukai.cpt202b.entity.Appo;
import group27.xukai.cpt202b.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

public interface UserRepo extends JpaRepository<User, Integer> {

    boolean existsByUsername(String username);
    boolean existsByEmail(String email);

    List<User> findByUsernameContainingIgnoreCase(String username);
    List<User> findByEmailContainingIgnoreCase(String email);
    List<User> findByGenderContainingIgnoreCase(String gender);

    @Query("SELECT u FROM User u")
    public List<User> findAll();

    public List<User> findByType(Integer type);

    public List<User> findByUsernameContaining(String username);

    public User findByUid(Integer uid);

//    public boolean existsByUsername(String username);
//
//    public boolean existsByEmail(String email);

    @Query("SELECT u FROM User u WHERE u.username = ?1")
    Optional<User> findByUsernameOptional(String username);


    public User findByUsername(String username);

    public List<Appo> findByUidIs(Integer uid);
    // return the appointment list with a specific username
    // public List<Appointment> findByUidIs(Integer uid);

    @Query("SELECT u FROM User u WHERE u.email = ?1")
    public Optional<User> findByEmail(String email);

    @Transactional
    @Modifying
    @Query(value = "DELETE FROM `user` WHERE uid = ?1", nativeQuery = true)
    public void deleteByUid(Integer uid);

    // 添加自定义查询的方法声明
//    List<User> findByAttribute(String attributeName, String value);
}











// package com.cpt202.appointment_system.Repositories;

// import java.util.List;
// import java.util.Optional;
// import org.springframework.data.jpa.repository.JpaRepository;
// import com.cpt202.appointment_system.Models.Appointment;
// import com.cpt202.appointment_system.Models.User;

// public interface UserRepo extends JpaRepository<User, Integer> {

//     public List<User> findByType(Integer type);

//     public List<User> findByUsernameContaining(String username);

//     public User findByUid(Integer uid);

//     public boolean existsByUsername(String username);

//     public boolean existsByEmail(String email);

//     public Optional<User> findByUsername(String username);

//     public Optional<User> findByEmail(String email);

//     // return the appointment list with a specific username
//     public List<Appointment> findByUidIs(Integer uid);

//     public User getbyusername(String username);
// }
