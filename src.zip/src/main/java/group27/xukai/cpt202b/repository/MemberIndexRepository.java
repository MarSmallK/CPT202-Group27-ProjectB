package group27.xukai.cpt202b.repository;

import group27.xukai.cpt202b.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MemberIndexRepository extends JpaRepository<User,Integer> {

}
