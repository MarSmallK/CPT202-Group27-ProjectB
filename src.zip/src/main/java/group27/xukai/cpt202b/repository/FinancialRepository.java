package group27.xukai.cpt202b.repository;

import group27.xukai.cpt202b.entity.Appo;
import group27.xukai.cpt202b.entity.PlanData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FinancialRepository extends JpaRepository<PlanData, Long> {

      @Query(value = "SELECT EXTRACT(MONTH FROM date_field) as month, SUM(total) AS totalPrice FROM (" +
              "SELECT start_time as date_field, balance as total " +
              "FROM member WHERE YEAR(start_time) = :year " +
              "UNION ALL " +
              "SELECT create_time as date_field, totalprice as total " +
              "FROM appointment WHERE YEAR(create_time) = :year AND status = 'Finished'" +
              ") combined GROUP BY month ORDER BY month", nativeQuery = true)
      List<Object[]> findProfitByMonth(@Param("year") int year);

      @Query(value = "SELECT * FROM fitness_plan WHERE MONTH(plan_date) = :month", nativeQuery = true)
      List<PlanData> findFitnessPlansByMonth(@Param("month") int month);

      @Query(value = "SELECT * FROM appointment WHERE MONTH(create_time) = :month", nativeQuery = true)
      List<Appo> findAppointmentsByMonth(@Param("month") int month);
}