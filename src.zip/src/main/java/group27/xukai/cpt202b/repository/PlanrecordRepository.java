package group27.xukai.cpt202b.repository;

import group27.xukai.cpt202b.entity.Planrecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface PlanrecordRepository extends JpaRepository<Planrecord, Integer> {
    @Query(value = "SELECT * FROM record WHERE username = :username", nativeQuery = true)
    Planrecord findByUserName(@Param("username") String username);
}
